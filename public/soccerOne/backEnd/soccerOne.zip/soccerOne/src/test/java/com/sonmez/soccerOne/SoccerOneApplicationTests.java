package com.sonmez.soccerOne;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoccerOneApplicationTests {

	@Test
	void contextLoads() {
	}

}
