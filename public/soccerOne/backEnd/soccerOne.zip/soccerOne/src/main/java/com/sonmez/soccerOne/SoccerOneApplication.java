package com.sonmez.soccerOne;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoccerOneApplication {

	public static void main(String[] args) {
		SpringApplication.run(SoccerOneApplication.class, args);
	}

}
